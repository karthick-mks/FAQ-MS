<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-8 no-pad">
				<h4>Category List</h4>
			</div>
			<div class="col-sm-4 text-right no-pad">
				<a href="<?php echo e(route('category.create')); ?>" class="btn btn-sm btn-primary"> Add Category</a>
			</div>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th width="10%">SNo.</th>
						<th>Name</th>
						<th>Description</th>
						<th>Operation</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=0;?>
					<?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td class="text-center"><?php echo ++$no;?></td>
						<td><?php echo e($categorys->name); ?></td>
						<td><?php echo e($categorys->description); ?></td>
						<td>
							<a href="<?php echo e(route('category.show', $categorys->id)); ?>" class="btn btn-sm btn-info">View</a>
							<a href="<?php echo e(route('category.edit', $categorys->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
							<form action="<?php echo e(route('category.destroy',$categorys->id)); ?>" method="POST" style="display:inline" onsubmit="return confirm('Are you sure?');">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="btn btn-sm btn-danger"> Delete</button>
							</form>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="4" class="text-center">No Records Found!.</td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo e($category->links()); ?>

		</div>	
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>