@extends('layouts.app')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h4>Question List</h4>
			</div>
			@forelse($question as $questions)
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<div data-toggle="collapse" href="#collapse{{$questions->id}}" class="collapsed"><b>{{$questions->name}} :</b> {{$questions->question}}</div>
							</h5>
						</div>
						<div id="collapse{{$questions->id}}" class="panel-collapse collapse">
							<div class="panel-body">{{$questions->answer}}</div>
						</div>
					</div>
				</div>
			@empty
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<a data-toggle="collapse" href="#collapse">No Records Found!.</a>
							</h5>
						</div>
					</div>
				</div>
			@endforelse
		</div>	
	</div>
@endsection