@extends('layouts.app')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-sm-8 no-pad">
				<h4>Question List</h4>
			</div>
			<div class="col-sm-4 text-right no-pad">
				<a href="{{route('question.create')}}" class="btn btn-sm btn-primary"> Add Question</a>
			</div>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th width="5%">SNo.</th>
						<th width="10%">Question</th>
						<th width="10%">Description</th>
						<th width="35%">Answer</th>
						<th width="5%">Total Read</th>
						<th width="5%">Helpful Yes</th>
						<th width="5%">Helpful No</th>
						<th width="10%">Category</th>
						<th width="5%">List Order</th>
						<th width="10%">Operation</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=0;?>
					@forelse($question as $questions)
					<tr>
						<td class="text-center"><?php echo ++$no;?></td>
						<td>{{$questions->question}}</td>
						<td>{{$questions->description}}</td>
						<td>{{$questions->answer}}</td>
						<td>{{$questions->total_read}}</td>
						<td>{{$questions->helpful_yes}}</td>
						<td>{{$questions->helpful_no}}</td>
						<td>{{$questions->name}}</td>
						<td>{{$questions->list_order}}</td>
						<td>
							<a href="{{ route('question.show', $questions->id) }}" class="btn btn-sm btn-info width-100">View</a>
							<a href="{{ route('question.edit', $questions->id) }}" class="btn btn-sm btn-primary width-100">Edit</a>
							<form action="{{route('question.destroy',$questions->id)}}" method="POST" style="display:inline" onsubmit="return confirm('Are you sure?');">
								<input type="hidden" name="_method" value="DELETE">
								{{csrf_field()}}
								<button class="btn btn-sm btn-danger width-100"> Delete</button>
							</form>
						</td>
					</tr>
					@empty
					<tr>
						<td colspan="10" class="text-center">No Records Found!.</td>
					</tr>
					@endforelse
				</tbody>
			</table>
			{{$question->links()}}
		</div>	
	</div>

@endsection