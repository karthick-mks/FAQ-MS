<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuesAns extends Model
{
    protected $fillable = ['question','description','answer','total_read','helpful_yes','helpful_no','category_id','list_order','created_by'];
	protected $dates = ['deleted_at'];
}
