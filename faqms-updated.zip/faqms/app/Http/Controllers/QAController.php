<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\QuesAns;
use App\Category;

class QAController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $question=QuesAns::leftjoin('categories',function($join){
			$join->on('ques_ans.category_id','=','categories.id');
		})
		->select('ques_ans.*','categories.name')
		->orderBy('ques_ans.id','desc')
		->paginate(5);
		return view('admin.question.index',compact('question'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$category = Category::select('name', 'id')->get();
        return view('admin.question.create',compact('category'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
			'question' => ['required', 'string', 'max:50'],
			'description' => ['required', 'string', 'max:255'],
			'answer' => ['required', 'string', 'max:500'],
			'category_id' => ['required']
		]);
        $question = new QuesAns([
			'question' => $request->get('question'),
			'description' => $request->get('description'),
			'answer' => $request->get('answer'),
			'total_read' => $request->get('total_read'),
			'helpful_yes' => $request->get('helpful_yes'),
			'helpful_no' => $request->get('helpful_no'),
			'category_id' => $request->get('category_id'),
			'list_order' => $request->get('list_order'),
			'created_by' => auth()->user()->id
		]);
		$question->save();
		/* Session::flash('flash_message', 'Question successfully added!'); */
		return redirect('admin/question');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		$category = Category::select('name', 'id')->get();
        $question = QuesAns::find($id);
		return view('admin.question.view',compact('question','id'),compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
		$category = Category::select('name', 'id')->get();
        $question = QuesAns::find($id);
		return view('admin.question.edit',compact('question','id'),compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $question = QuesAns::find($id);
        $this->validate($request, [
			'question' => ['required', 'string', 'max:50'],
			'description' => ['required', 'string', 'max:255'],
			'answer' => ['required', 'string', 'max:500'],
			'category_id' => ['required']
		]);
		$question -> question = $request->get('question');
		$question -> description = $request->get('description');
		$question -> answer = $request->get('answer');
		$question -> total_read = $request->get('total_read');
		$question -> helpful_yes = $request->get('helpful_yes');
		$question -> helpful_no = $request->get('helpful_no');
		$question -> category_id = $request->get('category_id');
		$question -> list_order = $request->get('list_order');
		$question -> created_by = $request->get('created_by');
		$question -> updated_by = auth()->user()->id;
		
		$question->save();
		return redirect('admin/question');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $question = QuesAns::find($id);
        
		$question->delete();
		
		return redirect('admin/question');
    }
}
