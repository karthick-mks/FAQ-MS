@extends('layouts.app')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h4>Question List</h4>
			</div>
			@forelse($category as $cate)
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<div data-toggle="collapse" href="#collapse{{$cate->id}}" class="collapsed"><b>{{$cate->name}}</b></div>
							</h5>
						</div>
						<div id="collapse{{$cate->id}}" class="panel-collapse collapse">
							<div class="panel-body">
								<ul class="list-question-answer">
									<?php $i=0;?>
									@forelse($question as $questions)
										@if ($questions->category_id == $cate->id)
											<?php $i++;?>
											<li>
												<div class="text-question">{{strtoupper($questions->question)}}</div>
												<div class="text-answer">{{$questions->answer}}</div>
											</li>
										@endif
									@empty
										<span class="text-danger">No Question & Answer Found!.</span>
									@endforelse
									@if ($i == 0)
										<span class="text-danger">No Question & Answer Found!.</span>
									@endif
								</ul>								
							</div>
						</div>
					</div>
				</div>
			@empty
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<span class="text-danger">No Question & Answer Found!.</span>
							</h5>
						</div>
					</div>
				</div>
			@endforelse
		</div>	
	</div>
@endsection