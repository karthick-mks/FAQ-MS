@extends('layouts.app')

@section('content')

	<div class="container">
		<div class="row">
			<div class="col-sm-8 no-pad">
				<h4>Category List</h4>
			</div>
			<div class="col-sm-4 text-right no-pad">
				<a href="{{route('category.create')}}" class="btn btn-sm btn-primary"> Add Category</a>
			</div>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th width="10%">SNo.</th>
						<th>Name</th>
						<th>Description</th>
						<th>Operation</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=0;?>
					@forelse($category as $categorys)
					<tr>
						<td class="text-center"><?php echo ++$no;?></td>
						<td>{{$categorys->name}}</td>
						<td>{{$categorys->description}}</td>
						<td>
							<a href="{{ route('category.show', $categorys->id) }}" class="btn btn-sm btn-info">View</a>
							<a href="{{ route('category.edit', $categorys->id) }}" class="btn btn-sm btn-primary">Edit</a>
							<form action="{{route('category.destroy',$categorys->id)}}" method="POST" style="display:inline" onsubmit="return confirm('Are you sure?');">
								<input type="hidden" name="_method" value="DELETE">
								{{csrf_field()}}
								<button class="btn btn-sm btn-danger"> Delete</button>
							</form>
						</td>
					</tr>
					@empty
					<tr>
						<td colspan="4" class="text-center">No Records Found!.</td>
					</tr>
					@endforelse
				</tbody>
			</table>
			{{$category->links()}}
		</div>	
	</div>

@endsection