@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">{{ __('Question') }}</div>

                <div class="card-body">
					@if(Session::has('flash_message'))
						<div class="alert alert-success">
							{{ Session::get('flash_message') }}
						</div>
					@endif
                    <form method="POST" action="{{ action('QAController@update',$id) }}">
                        @csrf

						<input type="hidden" name="_method" value="PATCH">
						<input type="hidden" name="created_by" value="{{$question->created_by}}">
                        <div class="form-group row">
                            <label for="question" class="col-md-3 col-form-label text-md-right">{{ __('Question') }}</label>

                            <div class="col-md-8">
                                 <textarea id="question" type="text" class="form-control{{ $errors->has('question') ? ' is-invalid' : '' }}" name="question" autofocus>{{$question->question}}</textarea>

                                @if ($errors->has('question'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('question') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-3 col-form-label text-md-right">{{ __('Description') }}</label>

                            <div class="col-md-8">
                                <textarea id="description" type="text" class="form-control{{ $errors->has('description') ? ' is-invalid' : '' }}" name="description">{{$question->description}}</textarea>

                                @if ($errors->has('description'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('description') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="description" class="col-md-3 col-form-label text-md-right">{{ __('Answer') }}</label>

                            <div class="col-md-8">
                                <textarea id="answer" type="text" class="form-control{{ $errors->has('answer') ? ' is-invalid' : '' }}" name="answer">{{$question->answer}}</textarea>

                                @if ($errors->has('answer'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('answer') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

						<div class="form-group row">
                            <label for="category_id" class="col-md-3 col-form-label text-md-right">{{ __('Category') }}</label>
							
							<div class="col-sm-8">
								<select name="category_id" class="form-control{{ $errors->has('category_id') ? ' is-invalid' : '' }}" id="category_id">
									<option selected disabled>Select category</option>
									@foreach($category as $cat)
										@if (($question->category_id) == ($cat->id))
											<option value="{{$cat->id}}" selected>{{$cat->name}}</option>
										@else
											<option value="{{$cat->id}}">{{$cat->name}}</option>
										@endif
									@endforeach
								</select>
								
                                @if ($errors->has('category_id'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('category_id') }}</strong>
                                    </span>
                                @endif
							</div>
						</div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
								<input type="hidden" name="total_read" value="{{$question->total_read}}">
								<input type="hidden" name="helpful_yes" value="{{$question->helpful_yes}}">
								<input type="hidden" name="helpful_no" value="{{$question->helpful_no}}">
								<input type="hidden" name="list_order" value="{{$question->list_order}}">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
