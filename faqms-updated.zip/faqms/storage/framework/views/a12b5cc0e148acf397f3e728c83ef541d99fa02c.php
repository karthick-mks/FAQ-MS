<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h4>Question List</h4>
			</div>
			<?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<div data-toggle="collapse" href="#collapse<?php echo e($cate->id); ?>" class="collapsed"><b><?php echo e($cate->name); ?></b></div>
							</h5>
						</div>
						<div id="collapse<?php echo e($cate->id); ?>" class="panel-collapse collapse">
							<div class="panel-body">
								<ul class="list-question-answer">
									<?php $i=0;?>
									<?php $__empty_2 = true; $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
										<?php if($questions->category_id == $cate->id): ?>
											<?php $i++;?>
											<li>
												<div class="text-question"><?php echo e(strtoupper($questions->question)); ?></div>
												<div class="text-answer"><?php echo e($questions->answer); ?></div>
											</li>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
										<span class="text-danger">No Question & Answer Found!.</span>
									<?php endif; ?>
									<?php if($i == 0): ?>
										<span class="text-danger">No Question & Answer Found!.</span>
									<?php endif; ?>
								</ul>								
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<span class="text-danger">No Question & Answer Found!.</span>
							</h5>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>