<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h4>Question List</h4>
			</div>
			<?php $__empty_1 = true; $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<div data-toggle="collapse" href="#collapse<?php echo e($questions->id); ?>" class="collapsed"><b><?php echo e($questions->name); ?> :</b> <?php echo e($questions->question); ?></div>
							</h5>
						</div>
						<div id="collapse<?php echo e($questions->id); ?>" class="panel-collapse collapse">
							<div class="panel-body"><?php echo e($questions->answer); ?></div>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="col-sm-12 panel-group">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h5 class="panel-title">
								<a data-toggle="collapse" href="#collapse">No Records Found!.</a>
							</h5>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>