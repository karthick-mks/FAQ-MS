<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-8 no-pad">
				<h4>Question List</h4>
			</div>
			<div class="col-sm-4 text-right no-pad">
				<a href="<?php echo e(route('question.create')); ?>" class="btn btn-sm btn-primary"> Add Question</a>
			</div>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th width="5%">SNo.</th>
						<th width="10%">Question</th>
						<th width="10%">Description</th>
						<th width="35%">Answer</th>
						<th width="5%">Total Read</th>
						<th width="5%">Helpful Yes</th>
						<th width="5%">Helpful No</th>
						<th width="10%">Category</th>
						<th width="5%">List Order</th>
						<th width="10%">Operation</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=0;?>
					<?php $__empty_1 = true; $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td class="text-center"><?php echo ++$no;?></td>
						<td><?php echo e($questions->question); ?></td>
						<td><?php echo e($questions->description); ?></td>
						<td><?php echo e($questions->answer); ?></td>
						<td><?php echo e($questions->total_read); ?></td>
						<td><?php echo e($questions->helpful_yes); ?></td>
						<td><?php echo e($questions->helpful_no); ?></td>
						<td><?php echo e($questions->name); ?></td>
						<td><?php echo e($questions->list_order); ?></td>
						<td>
							<a href="<?php echo e(route('question.show', $questions->id)); ?>" class="btn btn-sm btn-info width-100">View</a>
							<a href="<?php echo e(route('question.edit', $questions->id)); ?>" class="btn btn-sm btn-primary width-100">Edit</a>
							<form action="<?php echo e(route('question.destroy',$questions->id)); ?>" method="POST" style="display:inline" onsubmit="return confirm('Are you sure?');">
								<input type="hidden" name="_method" value="DELETE">
								<?php echo e(csrf_field()); ?>

								<button class="btn btn-sm btn-danger width-100"> Delete</button>
							</form>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="10" class="text-center">No Records Found!.</td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo e($question->links()); ?>

		</div>	
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>