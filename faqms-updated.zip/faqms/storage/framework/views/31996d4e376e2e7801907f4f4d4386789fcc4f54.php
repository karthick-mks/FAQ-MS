<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Question')); ?></div>

                <div class="card-body">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success">
							<?php echo e(Session::get('flash_message')); ?>

						</div>
					<?php endif; ?>
                    <form method="POST" action="<?php echo e(action('QAController@update',$id)); ?>">
                        <?php echo csrf_field(); ?>

						<input type="hidden" name="_method" value="PATCH">
						<input type="hidden" name="created_by" value="<?php echo e($question->created_by); ?>">
                        <div class="form-group row">
                            <label for="question" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Question')); ?></label>

                            <div class="col-md-8">
                                 <textarea id="question" type="text" class="form-control<?php echo e($errors->has('question') ? ' is-invalid' : ''); ?>" name="question" autofocus><?php echo e($question->question); ?></textarea>

                                <?php if($errors->has('question')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('question')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-8">
                                <textarea id="description" type="text" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description"><?php echo e($question->description); ?></textarea>

                                <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="description" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Answer')); ?></label>

                            <div class="col-md-8">
                                <textarea id="answer" type="text" class="form-control<?php echo e($errors->has('answer') ? ' is-invalid' : ''); ?>" name="answer"><?php echo e($question->answer); ?></textarea>

                                <?php if($errors->has('answer')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('answer')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

						<div class="form-group row">
                            <label for="category_id" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Category')); ?></label>
							
							<div class="col-sm-8">
								<select name="category_id" class="form-control<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>" id="category_id">
									<option selected disabled>Select category</option>
									<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(($question->category_id) == ($cat->id)): ?>
											<option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
										<?php else: ?>
											<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								
                                <?php if($errors->has('category_id')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('category_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
						</div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
								<input type="hidden" name="total_read" value="<?php echo e($question->total_read); ?>">
								<input type="hidden" name="helpful_yes" value="<?php echo e($question->helpful_yes); ?>">
								<input type="hidden" name="helpful_no" value="<?php echo e($question->helpful_no); ?>">
								<input type="hidden" name="list_order" value="<?php echo e($question->list_order); ?>">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>