$(document).ready(function(e) {
	
	//right click disable
	//document.addEventListener('contextmenu', event => event.preventDefault());
	
	/* if ($('.view-disable')[0]) {
		$(document).keydown(function(objEvent) {
		if (objEvent.keyCode == 9) {  //tab pressed
			objEvent.preventDefault(); // stops its action
		}
		});
	} */
	// $( document ).tooltip();
	//replace string in between numbers
	var intVal = function ( i ) 
	{
		return typeof i === 'string' ?
		i.replace(/[\$,]/g, '')*1 :
		typeof i === 'number' ?
		i : 0;
	};
	
	$('[data-toggle="tooltip"]').tooltip();
	
	$(function(){
		$(".chosen").chosen();
	});
	
	$('input').bind('copy paste', function () {
		var txt = $(this);
		var func = function() {
			txt.val(txt.val().trim());
		}
		txt.bind('copy paste').keyup(func).keypress(func).blur(func).change(func);
	});

	$("input").on("change focusout blur", function(e) {
    	if (e.which === 32 && !this.value.length)
        e.preventDefault();
		var txt = $(this);
		txt.val(txt.val().trim());
	});
	
	$("textarea").on("keyup focusout blur", function(e) {
    	if (e.which === 32 && !this.value.length)
        e.preventDefault();
	});
	
	//Numbers Only validation
	$(".numbersOnly").on("keypress keyup blur",function (event){
		$(this).val($(this).val().replace(/[^0-9\.]/g,''));
		if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57) && (event.which != 8))
		{
			event.preventDefault();
		}
	});
	
	$(".numbersOnly").on("keypress keyup blur",function (event){
		$(this).val($(this).val().replace(/[^0-9\.]/g,''));
		if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57) && (event.which != 8))
		{
			event.preventDefault();
		}
		if (this.value.length ==0 && event.which == 48 )
		{
			event.preventDefault();
		}
	});
	$(".pricefield").on("focusout",function (event){
		var $th = $(this);
		var number=$th.val();
		numbers = number.replace(/^0+/, '');
		var sum=0;
		while(number > 0)
		{
			sum = sum + number % 10 ;
			number = number / 10;
		}
		if(sum==0)
		{
			$th.val("");
		}
		else
		{
			$th.val(numbers);
		}
		if($th.val().length==1)
		{
			$th.val( $th.val().replace(/[0, ]/g, function(str) {  return ''; } ) );
		}
	});
	
	//Date picker
	$('body').on('focus',".txt_date", function(){
		 $('.datepickers').datepicker({
			yearRange: '1950:2100',
			changeMonth: true,
			changeYear: true,
			autoclose: true
		 });		
	});
	
	$("#save").click(function(e){

	});
	
	$("#save_new").click(function(e){

	});

	function getQueryVariable(variable) {
	  var query = window.location.search.substring(1);
	  var vars = query.split("&");
	  for (var i=0;i<vars.length;i++) {
		var pair = vars[i].split("=");
		if (pair[0] == variable) {
		  return pair[1];
		}
	  } 
	}

	var save = getQueryVariable("save");
	if(save=="success"){
		
		$("#success_alert").fadeTo(1500, 500).fadeOut(1000, function(){
			$("#success_alert").alert('close');
		});
	}
	
	var savenew = getQueryVariable("savenew");
	if(savenew=="success"){
		
		$("#success_alert1").fadeTo(1500, 500).fadeOut(1000, function(){
			$("#success_alert1").alert('close');
		});
	}
	
	$(document).on("click",".check",function(){
		
		if($(".check").length == $(".check:checked").length) {
			$(".selectall").prop("checked", true);
		} else {
			$(".selectall").prop('checked', false);
		}
	});
	$(document).on("click",".selectall",function(){				
		$(".check").prop("checked", true);
			
		if(this.checked) {
			$(".check").prop("checked", true);
			$(".uncheck").prop("checked", false);
	  	}else {
			$(".check").prop("checked", false);
	 	}
	});

	$(document).on('click','.activetab',function () {	
			if($('li.active'))
			{
				var tabname=$(this).text();
				$('.titlename').text(''+tabname+' ').css('font-weight', 'bold');
				$('.ttl').text('Buzzer Cloud ERP | '+tabname+' Add & List');
				$('.ttl').text('Buzzer Cloud ERP | '+tabname+' ');
			}
	});
	$(document).on('click','.activestab',function () {	
			if($('li.active'))
			{
				var tabname=$(this).text();
				$('.titlename').text(''+tabname+' Add & List').css('font-weight', 'bold');
				$('.ttl').text('Buzzer Cloud ERP | '+tabname+' ');
				$('.ttl').text('Buzzer Cloud ERP | '+tabname+' ');
			}
	});
	$(document).on('click','.activetabedit',function () {	
			if($('li.active'))
			{
				var tabname=$(this).text();
				$('.titlename').text(''+tabname+' Edit').css('font-weight', 'bold');
				$('.ttl').text('Buzzer Cloud ERP Edit | '+tabname);
			}
	});
	$(document).on('click','.activestabedit',function () {	
			if($('li.active'))
			{
				var tabname=$(this).text();
				$('.titlename').text(''+tabname+' Edit').css('font-weight', 'bold');
				$('.ttl').text('Buzzer Cloud ERP Edit | '+tabname);
			}
	});

	// chosen_required 
	$('.chosen_required').change(function(){
		var cho_reg=$(this).val();
		if(cho_reg)
		{
			$(this).next('label').removeClass('error');
			$(this).removeClass('error');
			$(this).next('label').css('display','none');
		}
		else
		{
			$(this).next('label').addClass('error');
			$(this).addClass('error');
			$(this).next('label').css('display','block');
		}
	});

	//Summernote text editor
	$('.summernote').summernote({
	  disableDragAndDrop:true,
	  height: 100, 
	  minHeight: 100, 
	  maxHeight: 200, 
	  toolbar: [
		// [groupName, [list of button]]
		['style', ['bold', 'italic', 'underline', 'clear']],
		['font', ['strikethrough']],
		['fontsize', ['fontsize']],
		['color', ['color']],
		['table', ['table']],
		['para', ['ul', 'ol', 'paragraph']],
	  ]
	});
	
	//form reset
	$( "button[type='reset']" ).click( function(){
		$( ".chosen" ).val('').trigger("chosen:updated");
	});
});

function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

function getSummerNote(){
	$(document).ready(function(e) {
		$('.summernote_edit').summernote({
		  disableDragAndDrop:true,
		  height: 100, 
		  minHeight: 100, 
		  maxHeight: 200, 
		  toolbar: [
			// [groupName, [list of button]]
			['style', ['bold', 'italic', 'underline', 'clear']],
			['font', ['strikethrough']],
			['fontsize', ['fontsize']],
			['color', ['color']],
			['table', ['table']],
			['para', ['ul', 'ol', 'paragraph']],
		  ]
		});
		$('.summernote_view').summernote({
		   disableDragAndDrop:true,
		   airMode: true,
		   disable:true,
		   height: 200, 
		   minHeight: 100, 
		});
	});
}

/* //disable view page source
shortcut = {
    all_shortcuts: {},
      add: function (e, t, n) {
        var r = {
          type: "keydown",
          propagate: !1,
          disable_in_input: !1,
          target: document,
          keycode: !1
        };
        if (n) for (var i in r) "undefined" == typeof n[i] && (n[i] = r[i]);
        else n = r;
        r = n.target, "string" == typeof n.target && (r = document.getElementById(n.target)), e = e.toLowerCase(), i = function (r) {
          r = r || window.event;
          if (n.disable_in_input) {
            var i;
            r.target ? i = r.target : r.srcElement && (i = r.srcElement), 3 == i.nodeType && (i = i.parentNode);
            if ("INPUT" == i.tagName || "TEXTAREA" == i.tagName) return
          }
          r.keyCode ? code = r.keyCode : r.which && (code = r.which), i = String.fromCharCode(code).toLowerCase(), 188 == code && (i = ","), 190 == code && (i = ".");
          var s = e.split("+"),
            o = 0,
            u = {
              "`": "~",
              1: "!",
              2: "@",
              3: "#",
              4: "$",
              5: "%",
              6: "^",
              7: "&",
              8: "*",
              9: "(",
              0: ")",
              "-": "_",
              "=": "+",
              ";": ":",
              "'": '"',
              ",": "<",
              ".": ">",
              "/": "?",
              "\\": "|"
            }, f = {
              esc: 27,
              escape: 27,
              tab: 9,
              space: 32,
              "return": 13,
              enter: 13,
              backspace: 8,
              scrolllock: 145,
              scroll_lock: 145,
              scroll: 145,
              capslock: 20,
              caps_lock: 20,
              caps: 20,
              numlock: 144,
              num_lock: 144,
              num: 144,
              pause: 19,
              "break": 19,
              insert: 45,
              home: 36,
              "delete": 46,
              end: 35,
              pageup: 33,
              page_up: 33,
              pu: 33,
              pagedown: 34,
              page_down: 34,
              pd: 34,
              left: 37,
              up: 38,
              right: 39,
              down: 40,
              f1: 112,
              f2: 113,
              f3: 114,
              f4: 115,
              f5: 116,
              f6: 117,
              f7: 118,
              f8: 119,
              f9: 120,
              f10: 121,
              f11: 122,
              f12: 123
            }, l = !1,
            c = !1,
            h = !1,
            p = !1,
            d = !1,
            v = !1,
            m = !1,
            y = !1;
          r.ctrlKey && (p = !0), r.shiftKey && (c = !0), r.altKey && (v = !0), r.metaKey && (y = !0);
          for (var b = 0; k = s[b], b < s.length; b++) "ctrl" == k || "control" == k ? (o++, h = !0) : "shift" == k ? (o++, l = !0) : "alt" == k ? (o++, d = !0) : "meta" == k ? (o++, m = !0) : 1 < k.length ? f[k] == code && o++ : n.keycode ? n.keycode == code && o++ : i == k ? o++ : u[i] && r.shiftKey && (i = u[i], i == k && o++);
          if (o == s.length && p == h && c == l && v == d && y == m && (t(r), !n.propagate)) return r.cancelBubble = !0, r.returnValue = !1, r.stopPropagation && (r.stopPropagation(), r.preventDefault()), !1
        }, this.all_shortcuts[e] = {
          callback: i,
          target: r,
          event: n.type
        }, r.addEventListener ? r.addEventListener(n.type, i, !1) : r.attachEvent ? r.attachEvent("on" + n.type, i) : r["on" + n.type] = i
      },
      remove: function (e) {
        var e = e.toLowerCase(),
          t = this.all_shortcuts[e];
        delete this.all_shortcuts[e];
        if (t) {
          var e = t.event,
            n = t.target,
            t = t.callback;
          n.detachEvent ? n.detachEvent("on" + e, t) : n.removeEventListener ? n.removeEventListener(e, t, !1) : n["on" + e] = !1
        }
      }
    },
     shortcut.add("Ctrl+U",function(){
     //alert('Sorry\nNo CTRL+U is allowed. Be creative!')
    }),
     shortcut.add("Meta+Alt+U",function(){
   //  alert('Sorry\nNo Command+Option+U is allowed. Be creative!')
    }),
    shortcut.add("Ctrl+C",function(){
    // alert('Sorry\nNever duplicate this article...')
    }),
    shortcut.add("Meta+C",function(){
     //alert('Sorry\nNever duplicate this article...')
    }); */
